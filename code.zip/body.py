import cv2
from ultralytics import YOLO
import requests
from datetime import datetime
import time
import io

TELEGRAM_CHAT_ID = "-5026762966"
TELEGRAM_BOT_TOKEN = "8532307798:AAHqv0yPLcfvgmSA4L5pd9nlr3ktYJbsqh4"
ALERT_COOLDOWN = 10
STUDY_TIME_THRESHOLD = 60  # 1 phút (60 giây) để test


class StudyMonitor:
    def __init__(self, model_path):
        self.model = YOLO(model_path)
        self.labels = ['Yawn', 'close_eye', 'drinking', 'seat belt', 'smoker', 'using phone']

        # Khởi tạo body detector từ OpenCV
        self.body_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_fullbody.xml')

        self.last_alert_time = {
            'close_eye': 0,
            'smoker': 0,
            'using phone': 0,
            'no_person': 0
        }

        self.study_start_time = None
        self.is_studying = False
        self.reward_sent = False
        self.person_detected = False

        self.alert_messages = {
            'close_eye': '<b>THÔNG BÁO HỌC TẬP</b>\n\nCon đang buồn ngủ khi học bài\nThời gian: {}\n\nPhụ huynh nên kiểm tra và nhắc nhở con nghỉ ngơi hợp lý.',
            'smoker': '<b>CẢNH BÁO QUAN TRỌNG</b>\n\nPhát hiện hút thuốc tại bàn học\nThời gian: {}\n\nĐây là hành vi nguy hiểm và không được phép. Vui lòng xử lý ngay.',
            'using phone': '<b>THÔNG BÁO HỌC TẬP</b>\n\nCon đang sử dụng điện thoại thay vì học bài\nThời gian: {}\n\nViệc này ảnh hưởng đến hiệu quả học tập.',
            'study_reward': '<b>THÔNG BÁO TÍCH CỰC</b>\n\nCon đã ngồi học tập trung được {} phút!\nThời gian: {}\n\nĐây là thái độ học tập rất tốt. Phụ huynh có thể khen thưởng để động viên con.',
            'no_person': '<b>CẢNH BÁO</b>\n\nHọc sinh đã rời khỏi bàn học\nThời gian: {}\n\nVui lòng kiểm tra tình hình.'
        }

    def detect_person(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        bodies = self.body_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=3, minSize=(50, 100))
        return len(bodies) > 0

    def send_telegram_photo(self, image, caption):
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto"

        _, buffer = cv2.imencode(".jpg", image)
        io_buf = io.BytesIO(buffer)

        try:
            files = {'photo': io_buf}
            data = {'chat_id': TELEGRAM_CHAT_ID, 'caption': caption, 'parse_mode': 'HTML'}
            response = requests.post(url, files=files, data=data, timeout=10)
            return response.status_code == 200
        except Exception as e:
            print(f"Lỗi gửi ảnh: {str(e)}")
            return False

    def send_alert(self, label, frame):
        current_time = time.time()

        if current_time - self.last_alert_time[label] < ALERT_COOLDOWN:
            return False

        self.last_alert_time[label] = current_time
        timestamp = datetime.now().strftime("%H:%M:%S - %d/%m/%Y")
        message = self.alert_messages[label].format(timestamp)

        if self.send_telegram_photo(frame, message):
            print(f"Đã gửi cảnh báo: {label}")
            return True
        return False

    def send_reward_message(self, frame):
        if self.reward_sent:
            return False

        study_duration = int((time.time() - self.study_start_time) / 60)
        timestamp = datetime.now().strftime("%H:%M:%S - %d/%m/%Y")
        message = self.alert_messages['study_reward'].format(study_duration, timestamp)

        if self.send_telegram_photo(frame, message):
            print(f"Đã gửi thông báo khen thưởng: học được {study_duration} phút")
            self.reward_sent = True
            return True
        return False

    def check_study_status(self, has_bad_behavior, person_detected):
        current_time = time.time()

        if has_bad_behavior or not person_detected:
            self.study_start_time = None
            self.is_studying = False
            self.reward_sent = False
        else:
            if not self.is_studying:
                self.study_start_time = current_time
                self.is_studying = True
                print("Bắt đầu tính giờ học tập...")

            study_duration = current_time - self.study_start_time

            if study_duration >= STUDY_TIME_THRESHOLD and not self.reward_sent:
                return True

        return False

    def process_frame(self, frame):
        results = self.model(frame, verbose=False)
        detected_behaviors = []
        has_bad_behavior = False

        # Kiểm tra có người trong khung hình không
        person_detected = self.detect_person(frame)

        # Nếu không phát hiện người, gửi cảnh báo
        if not person_detected:
            if self.person_detected:
                self.send_alert('no_person', frame)
            self.person_detected = False
        else:
            self.person_detected = True

        for result in results:
            boxes = result.boxes
            for box in boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                confidence = float(box.conf[0])
                class_id = int(box.cls[0])
                label = self.labels[class_id]

                if confidence < 0.5:
                    continue

                if label in ['close_eye', 'smoker', 'using phone']:
                    color = (0, 0, 255)
                    detected_behaviors.append((label, frame.copy()))
                    has_bad_behavior = True
                else:
                    color = (0, 255, 0)

                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                text = f"{label}: {confidence:.2f}"
                cv2.putText(frame, text, (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        for label, alert_frame in detected_behaviors:
            self.send_alert(label, alert_frame)

        if self.check_study_status(has_bad_behavior, person_detected):
            self.send_reward_message(frame)

        # Hiển thị trạng thái
        if person_detected:
            if self.is_studying and not self.reward_sent:
                study_time = int(time.time() - self.study_start_time)
                status_text = f"Dang hoc: {study_time}s"
                cv2.putText(frame, status_text, (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            else:
                cv2.putText(frame, "Co nguoi", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        else:
            cv2.putText(frame, "KHONG CO NGUOI!", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

        return frame

    def run(self, camera_id=0):
        cap = cv2.VideoCapture(camera_id)

        if not cap.isOpened():
            print("Không thể mở camera!")
            return

        print("Đã khởi động hệ thống giám sát bàn học")
        print("Nhấn 'q' để thoát")
        print("=" * 50)

        start_msg = "<b>HỆ THỐNG GIÁM SÁT BÀN HỌC</b>\n\nĐã khởi động thành công.\nHệ thống sẽ tự động gửi thông báo kèm hình ảnh khi phát hiện hành vi không phù hợp."
        self.send_telegram_photo(cap.read()[1], start_msg)

        try:
            while True:
                ret, frame = cap.read()

                if not ret:
                    print("Không thể đọc frame từ camera!")
                    break

                processed_frame = self.process_frame(frame)
                cv2.imshow('Study Monitoring System', processed_frame)

                if cv2.waitKey(1) & 0xFF == ord('q'):
                    print("\nĐang dừng hệ thống...")
                    break

        finally:
            end_msg = "<b>HỆ THỐNG GIÁM SÁT BÀN HỌC</b>\n\nĐã dừng hoạt động."
            url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
            requests.post(url, json={"chat_id": TELEGRAM_CHAT_ID, "text": end_msg, "parse_mode": "HTML"})

            cap.release()
            cv2.destroyAllWindows()
            print("Đã dừng hệ thống")


if __name__ == "__main__":
    MODEL_PATH = "best.pt"

    monitor = StudyMonitor(MODEL_PATH)
    monitor.run(camera_id=0)